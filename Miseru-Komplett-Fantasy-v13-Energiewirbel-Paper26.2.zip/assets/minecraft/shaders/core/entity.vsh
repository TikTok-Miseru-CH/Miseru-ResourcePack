#version 330
#extension GL_ARB_shader_draw_parameters : enable

#if defined(PER_FACE_LIGHTING) || !defined(NO_CARDINAL_LIGHTING)
#moj_import <minecraft:light.glsl>
#endif
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

#ifndef NO_OVERLAY
uniform sampler2D Sampler1;
#endif

#ifndef EMISSIVE
uniform sampler2D Sampler2;
#endif

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

#ifdef PER_FACE_LIGHTING
out vec4 vertexPerFaceColorBack;
out vec4 vertexPerFaceColorFront;
#else
out vec4 vertexColor;
#endif

#ifndef EMISSIVE
out vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
out vec4 overlayColor;
#endif

out vec2 texCoord0;


// Miseru native equipment: front quad carries the already animated bone frame.
uniform sampler2D Sampler0;
flat out int miseruPart;
out vec3 miseruOriginal;
out vec3 miseruLocalPoint;
out vec3 miseruRayPoint;
out vec3 miseruForward;
vec3 miseruLocal(int part, int vertex) {
 if(part==1) { const vec3 q[4]=vec3[4](vec3(0.31250000,0.56250000,0.31250000),vec3(-0.31250000,0.56250000,0.31250000),vec3(-0.31250000,-0.06250000,0.31250000),vec3(0.31250000,-0.06250000,0.31250000)); return q[vertex]; }
 if(part==3) { const vec3 q[4]=vec3[4](vec3(0.12500000,0.18750000,0.18750000),vec3(-0.25000000,0.18750000,0.18750000),vec3(-0.25000000,-0.68750000,0.18750000),vec3(0.12500000,-0.68750000,0.18750000)); return q[vertex]; }
 if(part==4) { const vec3 q[4]=vec3[4](vec3(-0.12500000,-0.68750000,0.18750000),vec3(0.25000000,-0.68750000,0.18750000),vec3(0.25000000,0.18750000,0.18750000),vec3(-0.12500000,0.18750000,0.18750000)); return q[vertex]; }
 if(part==2) { const vec3 q[4]=vec3[4](vec3(0.31250000,0.06250000,0.18750000),vec3(-0.31250000,0.06250000,0.18750000),vec3(-0.31250000,-0.81250000,0.18750000),vec3(0.31250000,-0.81250000,0.18750000)); return q[vertex]; }
 if(part==7) { const vec3 q[4]=vec3[4](vec3(-0.15000000,-0.77500000,0.15000000),vec3(0.15000000,-0.77500000,0.15000000),vec3(0.15000000,0.02500000,0.15000000),vec3(-0.15000000,0.02500000,0.15000000)); return q[vertex]; }
 if(part==6) { const vec3 q[4]=vec3[4](vec3(0.15000000,0.02500000,0.15000000),vec3(-0.15000000,0.02500000,0.15000000),vec3(-0.15000000,-0.77500000,0.15000000),vec3(0.15000000,-0.77500000,0.15000000)); return q[vertex]; }
 if(part==5) { const vec3 q[4]=vec3[4](vec3(0.28125000,0.03125000,0.15625000),vec3(-0.28125000,0.03125000,0.15625000),vec3(-0.28125000,-0.78125000,0.15625000),vec3(0.28125000,-0.78125000,0.15625000)); return q[vertex]; }
 if(part==9) { const vec3 q[4]=vec3[4](vec3(-0.18125000,-0.80625000,0.18125000),vec3(0.18125000,-0.80625000,0.18125000),vec3(0.18125000,0.05625000,0.18125000),vec3(-0.18125000,0.05625000,0.18125000)); return q[vertex]; }
 if(part==8) { const vec3 q[4]=vec3[4](vec3(0.18125000,0.05625000,0.18125000),vec3(-0.18125000,0.05625000,0.18125000),vec3(-0.18125000,-0.80625000,0.18125000),vec3(0.18125000,-0.80625000,0.18125000)); return q[vertex]; }
 return vec3(0);
}
void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

#ifdef PER_FACE_LIGHTING
    vec2 light = minecraft_compute_light(Light0_Direction, Light1_Direction, Normal);
    vertexPerFaceColorBack = minecraft_mix_light_separate(-light, Color);
    vertexPerFaceColorFront = minecraft_mix_light_separate(light, Color);
#elif defined(NO_CARDINAL_LIGHTING)
    vertexColor = Color;
#else
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
#endif

#ifndef EMISSIVE
    lightMapColor = sample_lightmap(Sampler2, UV2);
#endif

#ifndef NO_OVERLAY
    overlayColor = texelFetch(Sampler1, UV1, 0);
#endif

    texCoord0 = UV0;

#ifdef APPLY_TEXTURE_MATRIX
    texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif

    miseruPart=0;
    miseruOriginal=vec3(0); miseruLocalPoint=vec3(0); miseruRayPoint=vec3(0); miseruForward=vec3(0,0,1);
    // Avoid interference with skins, other equipment, items, glint and entities.
#ifdef GL_ARB_shader_draw_parameters
    if(textureSize(Sampler0,0)==ivec2(1024,512) &&
       !(UV0.x > 0.875 && UV0.y >= 0.5) &&
       all(equal(ivec4(round(texelFetch(Sampler0,ivec2(0,0),0)*255.0)),ivec4(97,41,203,255)))) {
        int layer=int(round(texelFetch(Sampler0,ivec2(1,0),0).r*255.0));
        int meshVertex=gl_VertexID;
#ifdef GL_ARB_shader_draw_parameters
        meshVertex-=gl_BaseVertexARB;
#endif
        int vertex=meshVertex%4;
        vec2 uv=round(UV0*vec2(64,32));
        if((meshVertex/4)%6==3) {
            if(uv.x>=8.0 && uv.x<=16.0 && uv.y<=16.0) miseruPart=1;
            else if(uv.x>=20.0 && uv.x<=28.0 && uv.y>=20.0) miseruPart=layer==2?5:2;
            else if(uv.x>=44.0 && uv.x<=48.0 && uv.y>=20.0) {
                bool left=vertex<2?uv.y>26.0:uv.y<26.0; miseruPart=left?4:3;
            } else if(uv.x>=4.0 && uv.x<=8.0 && uv.y>=20.0) {
                bool left=vertex<2?uv.y>26.0:uv.y<26.0; miseruPart=(layer==2?6:8)+(left?1:0);
            }
        }
        if(miseruPart==0) {gl_Position=vec4(2,2,2,1); return;}
        miseruOriginal=(ModelViewMat*vec4(Position,1)).xyz;
        miseruForward=normalize(mat3(ModelViewMat)*Normal);
        miseruLocalPoint=miseruLocal(miseruPart,vertex);
        const vec2 corners[4]=vec2[4](vec2(-1,1),vec2(-1,-1),vec2(1,-1),vec2(1,1));
        // Conservative screen coverage; the fragment shader clips to real boxes.
        float radius=miseruPart==2?2.0:1.35;
        bool perspective=abs(ProjMat[3][3])<0.5;
        if(!perspective) radius*=64.0;
        miseruRayPoint=miseruOriginal+vec3(corners[vertex]*radius,0);
        if(perspective) miseruRayPoint.z=min(miseruRayPoint.z,-0.05);
        gl_Position=ProjMat*vec4(miseruRayPoint,1);
    }
#endif
}
