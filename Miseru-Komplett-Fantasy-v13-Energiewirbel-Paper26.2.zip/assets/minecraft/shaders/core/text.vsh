#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif

// Only the three reserved quest text colors are moved, and only in the GUI.
// The server pads each row to 140 GUI pixels; a negative space resets x.
#ifdef IS_GUI
    vec3 rgb = Color.rgb * 255.0;
    int questRow = -1;
    bool questShadow = false;
    for (int row = 0; row < 3; row++) {
        vec3 marker = vec3(249.0, 215.0, 89.0 + float(row) * 64.0);
        if (all(lessThan(abs(rgb - marker), vec3(0.6)))) questRow = row;
        if (all(lessThan(abs(rgb - floor(marker * 0.25)), vec3(0.6)))) {
            questRow = row;
            questShadow = true;
        }
    }
    if (questRow >= 0) {
        vec4 pos = ModelViewMat * vec4(Position, 1.0);
        float screenWidth = 2.0 / ProjMat[0][0];
        float screenHeight = -2.0 / ProjMat[1][1];
        pos.x += 78.0 - floor(screenWidth * 0.5);
        // Vanilla boss titles have y = 3 + 19*n; the compact glyph is y+1..8.
        pos.y = screenHeight * 0.5 - 16.0 + float(questRow) * 10.0 + mod(pos.y, 19.0);
        gl_Position = ProjMat * pos;
        vec3 ink = questRow == 0 ? vec3(1.0, 0.82, 0.35) : (questRow == 1 ? vec3(1.0) : vec3(0.45, 0.93, 0.94));
        vertexColor = vec4(ink * (questShadow ? 0.25 : 1.0), Color.a);
    }
#endif

    texCoord0 = UV0;
}
